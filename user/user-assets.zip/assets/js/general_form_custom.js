/*=========================================================================================
[General Form Custom Javascript]

Project	     : Seipkon - Responsive Admin Template
Author       : Hassan Rasu
Author URL   : https://themeforest.net/user/themescare
Version      : 1.0
Primary use  : Seipkon - Responsive Admin Template

Only Use For General Form (general-form.html) Page.

==========================================================================================*/


(function ($) {
	"use strict";

	jQuery(document).ready(function ($) {


		/* 
		=================================================================
		Tooltil Switch JS
		=================================================================	
		*/

		$('.toggle').toggles({
			on: true,
			height: 26
		});


	});


}(jQuery));